import Link from "next/link"
import { CheckSquare, Calendar, Clock, Star, Settings, HelpCircle } from "lucide-react"

export function DashboardNav() {
  return (
    <nav className="w-64 border-r p-4 hidden md:block">
      <div className="space-y-1">
        <NavItem href="/dashboard" icon={<CheckSquare />} active>
          Tasks
        </NavItem>
        <NavItem href="/calendar" icon={<Calendar />}>
          Calendar
        </NavItem>
        <NavItem href="/upcoming" icon={<Clock />}>
          Upcoming
        </NavItem>
        <NavItem href="/important" icon={<Star />}>
          Important
        </NavItem>
      </div>

      <div className="mt-8 pt-4 border-t">
        <h3 className="text-xs font-semibold text-gray-500 mb-2 px-3">SETTINGS</h3>
        <div className="space-y-1">
          <NavItem href="/settings" icon={<Settings />}>
            Settings
          </NavItem>
          <NavItem href="/help" icon={<HelpCircle />}>
            Help & Support
          </NavItem>
        </div>
      </div>

      {/* Pro upgrade banner - will implement later */}
      <div className="mt-auto pt-6">
        <div className="bg-primary/10 rounded-lg p-4">
          <h4 className="font-medium mb-1">Upgrade to Pro</h4>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">Get more features and priority support</p>
          <Link href="/upgrade">
            <button className="bg-primary text-primary-foreground w-full py-1.5 rounded-md text-sm font-medium">
              Upgrade
            </button>
          </Link>
        </div>
      </div>
    </nav>
  )
}

// Navigation item component
function NavItem({ href, icon, children, active = false }) {
  return (
    <Link
      href={href}
      className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm ${
        active
          ? "bg-primary/10 text-primary font-medium"
          : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
      }`}
    >
      {icon}
      <span>{children}</span>
    </Link>
  )
}
