// This is a mock implementation for demo purposes
// In a real app, you'd use a proper auth provider like NextAuth.js, Clerk, etc.

// Mock user data
const MOCK_USER = {
  id: "user_123",
  name: "John Doe",
  email: "john@example.com",
  password: "password123", // Never store passwords like this in a real app!
}

// Simulate login
export async function loginUser(email: string, password: string): Promise<any> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 800))

  // Super basic validation - NEVER do this in production!
  if (email === MOCK_USER.email && password === MOCK_USER.password) {
    // Store user in localStorage to simulate session
    localStorage.setItem(
      "user",
      JSON.stringify({
        id: MOCK_USER.id,
        name: MOCK_USER.name,
        email: MOCK_USER.email,
      }),
    )
    return MOCK_USER
  }

  throw new Error("Invalid credentials")
}

// Simulate registration
export async function registerUser(name: string, email: string, password: string): Promise<any> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // In a real app, you'd create a new user in your database
  const newUser = {
    id: `user_${Date.now()}`,
    name,
    email,
  }

  // Store user in localStorage to simulate session
  localStorage.setItem("user", JSON.stringify(newUser))

  return newUser
}

// Simulate logout
export async function logoutUser(): Promise<void> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 300))

  // Remove user from localStorage
  localStorage.removeItem("user")
}

// Get current user
export function getCurrentUser(): any {
  if (typeof window === "undefined") return null

  const userJson = localStorage.getItem("user")
  if (!userJson) return null

  try {
    return JSON.parse(userJson)
  } catch (err) {
    console.error("Failed to parse user from localStorage:", err)
    return null
  }
}

// Check if user is authenticated
export function isAuthenticated(): boolean {
  return !!getCurrentUser()
}
