// This is a mock implementation for demo purposes
// In a real app, you'd use a database or API

import { v4 as uuidv4 } from "uuid"

// Task type definition
type Task = {
  id: string
  title: string
  completed: boolean
  dueDate?: string
  createdAt: string
}

// Mock tasks data
let MOCK_TASKS: Task[] = [
  {
    id: "task_1",
    title: "Complete project proposal",
    completed: false,
    createdAt: "2024-05-10T10:30:00Z",
  },
  {
    id: "task_2",
    title: "Buy groceries",
    completed: true,
    createdAt: "2024-05-09T15:45:00Z",
  },
  {
    id: "task_3",
    title: "Schedule dentist appointment",
    completed: false,
    createdAt: "2024-05-08T09:15:00Z",
  },
  {
    id: "task_4",
    title: "Finish reading book",
    completed: false,
    createdAt: "2024-05-07T20:00:00Z",
  },
]

// Get all tasks
export async function getTasks(): Promise<Task[]> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 800))

  // In a real app, you'd fetch from an API or database
  // For now, we'll use localStorage to persist tasks between page refreshes
  if (typeof window !== "undefined") {
    const storedTasks = localStorage.getItem("tasks")
    if (storedTasks) {
      try {
        MOCK_TASKS = JSON.parse(storedTasks)
      } catch (err) {
        console.error("Failed to parse tasks from localStorage:", err)
      }
    }
  }

  return [...MOCK_TASKS].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
}

// Add a new task
export async function addTask(title: string): Promise<Task> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  const newTask: Task = {
    id: uuidv4(),
    title,
    completed: false,
    createdAt: new Date().toISOString(),
  }

  MOCK_TASKS = [newTask, ...MOCK_TASKS]

  // Save to localStorage
  if (typeof window !== "undefined") {
    localStorage.setItem("tasks", JSON.stringify(MOCK_TASKS))
  }

  return newTask
}

// Toggle task completion
export async function toggleTask(taskId: string): Promise<void> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 300))

  MOCK_TASKS = MOCK_TASKS.map((task) => (task.id === taskId ? { ...task, completed: !task.completed } : task))

  // Save to localStorage
  if (typeof window !== "undefined") {
    localStorage.setItem("tasks", JSON.stringify(MOCK_TASKS))
  }
}

// Delete a task
export async function deleteTask(taskId: string): Promise<void> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 300))

  MOCK_TASKS = MOCK_TASKS.filter((task) => task.id !== taskId)

  // Save to localStorage
  if (typeof window !== "undefined") {
    localStorage.setItem("tasks", JSON.stringify(MOCK_TASKS))
  }
}

// Update a task
export async function updateTask(taskId: string, updates: Partial<Task>): Promise<Task> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  let updatedTask: Task | null = null

  MOCK_TASKS = MOCK_TASKS.map((task) => {
    if (task.id === taskId) {
      updatedTask = { ...task, ...updates }
      return updatedTask
    }
    return task
  })

  // Save to localStorage
  if (typeof window !== "undefined") {
    localStorage.setItem("tasks", JSON.stringify(MOCK_TASKS))
  }

  if (!updatedTask) {
    throw new Error(`Task with ID ${taskId} not found`)
  }

  return updatedTask
}
