"use client"

import { useState, useEffect } from "react"
import { Plus, Calendar, Clock, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardNav } from "@/components/dashboard-nav"
import { getTasks, addTask, toggleTask, deleteTask } from "@/lib/tasks"

// Task type definition
// TODO: move this to a types file
type Task = {
  id: string
  title: string
  completed: boolean
  dueDate?: string
  createdAt: string
}

export default function DashboardPage() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [newTaskTitle, setNewTaskTitle] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  // Load tasks on component mount
  useEffect(() => {
    async function loadTasks() {
      try {
        // In a real app, this would fetch from an API
        const loadedTasks = await getTasks()
        setTasks(loadedTasks)
      } catch (err) {
        console.error("Failed to load tasks:", err)
      } finally {
        setIsLoading(false)
      }
    }

    loadTasks()
  }, [])

  // Add a new task
  async function handleAddTask(e) {
    e.preventDefault()

    if (!newTaskTitle.trim()) return

    try {
      const newTask = await addTask(newTaskTitle)
      setTasks((prev) => [newTask, ...prev])
      setNewTaskTitle("")
    } catch (err) {
      console.error("Failed to add task:", err)
    }
  }

  // Toggle task completion
  async function handleToggleTask(taskId: string) {
    try {
      await toggleTask(taskId)
      setTasks((prev) => prev.map((task) => (task.id === taskId ? { ...task, completed: !task.completed } : task)))
    } catch (err) {
      console.error("Failed to toggle task:", err)
    }
  }

  // Delete a task
  async function handleDeleteTask(taskId: string) {
    try {
      await deleteTask(taskId)
      setTasks((prev) => prev.filter((task) => task.id !== taskId))
    } catch (err) {
      console.error("Failed to delete task:", err)
    }
  }

  // Filter tasks based on tab
  const completedTasks = tasks.filter((task) => task.completed)
  const pendingTasks = tasks.filter((task) => !task.completed)

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader />

      <div className="flex flex-1">
        <DashboardNav />

        <main className="flex-1 p-6">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-3xl font-bold">Tasks</h1>
            <Button>
              <Calendar className="mr-2 h-4 w-4" />
              Calendar View
            </Button>
          </div>

          <Card className="mb-6">
            <CardHeader className="pb-3">
              <CardTitle>Add New Task</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAddTask} className="flex gap-2">
                <Input
                  placeholder="What needs to be done?"
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  className="flex-1"
                />
                <Button type="submit" disabled={!newTaskTitle.trim()}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add
                </Button>
              </form>
            </CardContent>
          </Card>

          <Tabs defaultValue="all">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All ({tasks.length})</TabsTrigger>
              <TabsTrigger value="pending">Pending ({pendingTasks.length})</TabsTrigger>
              <TabsTrigger value="completed">Completed ({completedTasks.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-4">
              {isLoading ? (
                <div className="text-center py-10">Loading tasks...</div>
              ) : tasks.length === 0 ? (
                <div className="text-center py-10 text-gray-500">No tasks yet. Add your first task above!</div>
              ) : (
                tasks.map((task) => (
                  <TaskItem key={task.id} task={task} onToggle={handleToggleTask} onDelete={handleDeleteTask} />
                ))
              )}
            </TabsContent>

            <TabsContent value="pending" className="space-y-4">
              {isLoading ? (
                <div className="text-center py-10">Loading tasks...</div>
              ) : pendingTasks.length === 0 ? (
                <div className="text-center py-10 text-gray-500">No pending tasks. Good job!</div>
              ) : (
                pendingTasks.map((task) => (
                  <TaskItem key={task.id} task={task} onToggle={handleToggleTask} onDelete={handleDeleteTask} />
                ))
              )}
            </TabsContent>

            <TabsContent value="completed" className="space-y-4">
              {isLoading ? (
                <div className="text-center py-10">Loading tasks...</div>
              ) : completedTasks.length === 0 ? (
                <div className="text-center py-10 text-gray-500">No completed tasks yet.</div>
              ) : (
                completedTasks.map((task) => (
                  <TaskItem key={task.id} task={task} onToggle={handleToggleTask} onDelete={handleDeleteTask} />
                ))
              )}
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}

// Task item component
function TaskItem({ task, onToggle, onDelete }) {
  return (
    <div className="flex items-center p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
      <Checkbox checked={task.completed} onCheckedChange={() => onToggle(task.id)} className="mr-3" />
      <div className="flex-1">
        <p className={`${task.completed ? "line-through text-gray-500" : ""}`}>{task.title}</p>
        <div className="flex items-center mt-1 text-xs text-gray-500">
          <Clock className="h-3 w-3 mr-1" />
          <span>Created {new Date(task.createdAt).toLocaleDateString()}</span>
        </div>
      </div>
      <Button
        variant="ghost"
        size="icon"
        onClick={() => onDelete(task.id)}
        className="text-gray-500 hover:text-red-500"
      >
        <Trash2 className="h-4 w-4" />
      </Button>
    </div>
  )
}
