import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, CheckCircle } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b px-4 py-3">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-xl font-bold">TaskFlow</h1>
          <div className="flex gap-4">
            <Link href="/login">
              <Button variant="ghost">Login</Button>
            </Link>
            <Link href="/signup">
              <Button>Get Started</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-20 px-4">
          <div className="container mx-auto max-w-5xl">
            <div className="flex flex-col md:flex-row gap-12 items-center">
              <div className="md:w-1/2 space-y-6">
                <h1 className="text-4xl md:text-5xl font-bold tracking-tight">Manage your tasks like never before</h1>
                <p className="text-lg text-gray-600 dark:text-gray-400">
                  Stop forgetting important stuff. TaskFlow helps you organize your life without the complexity.
                </p>
                <div className="flex flex-col sm:flex-row gap-3">
                  <Link href="/signup">
                    <Button size="lg" className="w-full sm:w-auto">
                      Start for free
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="/features">
                    <Button variant="outline" size="lg" className="w-full sm:w-auto">
                      See all features
                    </Button>
                  </Link>
                </div>

                <div className="pt-4">
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>No credit card required</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span>Cancel anytime</span>
                  </div>
                </div>
              </div>

              <div className="md:w-1/2">
                <div className="bg-gray-100 dark:bg-gray-800 rounded-xl p-6 shadow-lg">
                  {/* TODO: replace with actual screenshot */}
                  <div className="aspect-video bg-white dark:bg-gray-700 rounded-lg shadow-sm"></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-gray-50 dark:bg-gray-900 px-4">
          <div className="container mx-auto max-w-5xl">
            <h2 className="text-3xl font-bold text-center mb-12">Why people love TaskFlow</h2>

            <div className="grid md:grid-cols-3 gap-8">
              {features.map((feature, i) => (
                <div key={i} className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t py-8 px-4">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-sm text-gray-600 dark:text-gray-400">© 2024 TaskFlow. All rights reserved.</div>
            <div className="flex gap-6">
              <Link
                href="/privacy"
                className="text-sm text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100"
              >
                Privacy
              </Link>
              <Link
                href="/terms"
                className="text-sm text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100"
              >
                Terms
              </Link>
              <Link
                href="/contact"
                className="text-sm text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100"
              >
                Contact
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

// hardcoded features - will move to a separate file later
const features = [
  {
    title: "Simple & Intuitive",
    description: "No steep learning curve. Just start adding tasks and get things done.",
    icon: <CheckCircle className="h-6 w-6 text-primary" />,
  },
  {
    title: "Works Everywhere",
    description: "Access your tasks from any device - desktop, tablet, or mobile.",
    icon: <CheckCircle className="h-6 w-6 text-primary" />,
  },
  {
    title: "Stay Organized",
    description: "Create projects, set priorities, and never miss a deadline again.",
    icon: <CheckCircle className="h-6 w-6 text-primary" />,
  },
]
